# SwaggerJsClient.Vendor

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vendorId** | **Number** |  | [optional] 
**vendorName** | **String** |  | 
