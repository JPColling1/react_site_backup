# SwaggerJsClient.Company

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**companyId** | **Number** |  | [optional] 
**companyName** | **String** |  | 
